package com.example.ass7

class Employee (val name : String, val gender : String, val email : String, val salary : Int) {
}